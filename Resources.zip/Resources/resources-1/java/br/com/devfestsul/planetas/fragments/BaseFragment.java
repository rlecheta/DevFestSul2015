package br.com.devfestsul.planetas.fragments;

import android.support.v4.app.Fragment;

/**
 * Created by rlech on 11-Nov-15.
 */
public class BaseFragment extends Fragment {
}
