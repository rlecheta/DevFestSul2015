package br.com.devfestsul.planetas.fragments;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import br.com.devfestsul.planetas.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class PlanetaFragment extends BaseFragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_planeta, container, false);

        int imgPlaneta = getArguments().getInt("imgPlaneta", 0);
        if (imgPlaneta > 0) {
            ImageView img = (ImageView) view.findViewById(R.id.img);
			// (1) Chave da animação
            // ViewCompat.setTransitionName(img, getString(R.string.transition_key));
            img.setImageResource(imgPlaneta);
        }

        return view;
    }

}
